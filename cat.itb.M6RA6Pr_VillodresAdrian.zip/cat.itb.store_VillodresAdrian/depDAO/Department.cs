﻿namespace cat.itb.store_VillodresAdrian.depDAO
{
    public class Department
    {
        public virtual int _id { get; set; }
        public virtual string Name { get; set; }
        public virtual string Loc { get; set; }
        
    }
}

